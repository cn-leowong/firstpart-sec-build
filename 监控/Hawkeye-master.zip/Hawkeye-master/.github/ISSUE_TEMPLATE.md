### 描述

### 部署方式（Docker或其它）

### 错误日志

贴上 `docker exec xxxx tail -f /var/log/supervisor/* ` 结果

