<template>
    <div class="divider"></div>
</template>

<script>
    export default {
        name: "Divider"
    }
</script>

<style scoped>
    .divider {
        border-bottom: 1px dashed #e8e8e8;
    }
</style>