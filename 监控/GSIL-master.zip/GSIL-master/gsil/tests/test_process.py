from gsil.process import clone


def test_clone():
    clone('https://github.com/FeeiCN/dict', 'ttt')
