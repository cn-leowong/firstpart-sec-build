# Ty2yAntiVirus
开源杀毒软件

官网：http://ty2y.com/ty2yantivirus.html

专业的、正二八经的杀毒软件。

# Auther
WangLiwen

Email：6465660@qq.com

微信/Tel：13015406167

<img src="http://www.sharewaf.com/browserwaf/me.jpg" style="max-width:290px;width:100%;"/><br>

# 简介
小巧易用、简单轻便的杀毒软件。

病毒查杀、实时防护皆备，即可杀毒，又可防毒。

轻量级，无繁杂的设置、无复杂的使用。

没有多余的进程，没有众多的API监控，对系统性能无影响，不影响电脑运行速度。

还有众多轻便功能，如：开机自启、病毒库自动更新、三种不同扫描模式。

<img src="http://ty2y.com/images/screen/ty2y_antivirus_screen_03.jpg" style="max-width:290px;width:100%;"/><br>

<img src="http://ty2y.com/images/screen/ty2y_antivirus_2019_2.jpg" style="max-width:290px;width:100%;"/><br>

# 其它说明
* 源码：VB6（-_-!） & VC（DLL部分、使用VS2010编译）。
* 这里只是源码，没有带病毒库及其它文件，到官网下载安装软件后即可获取其它所缺外部文件。
* DLL编译依赖minhook。

# 捐助
<img src="http://www.sharewaf.com/browserwaf/mei_ye.jpg" style="max-width:634px;width:100%;"/>

<img src="http://www.sharewaf.com/browserwaf/wx.jpg" style="max-width:522px;width:100%;"/>

谢谢
