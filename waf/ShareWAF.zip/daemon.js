﻿/*
 * ShareWAF 守护进程
 * 功能：检测ShareWAF工作是否正常，如出现异常：无法访问，则对其进行重启
 * 本程序可以用forever启动，防止本进程出异常退出
 */
process.env.UV_THREADPOOL_SIZE = 128;

const { exec } = require('child_process');

/*
 * 启动ShareWAF
 */
function start_sharewaf(){
  exec('forever start sharewaf.js', (error, stdout, stderr) => {
    if (error) {
      console.error(`exec error: ${error}`);
      return;
    }
    console.log(`stdout: ${stdout}`);
    console.log(`stderr: ${stderr}`);
  });
}

/*
 * 关闭ShareWAF
 */
function stop_sharewaf(){
  exec('forever stop sharewaf.js', (error, stdout, stderr) => {
    if (error) {
      console.error(`exec error: ${error}`);
      return;
    }
    console.log(`stdout: ${stdout}`);
    console.log(`stderr: ${stderr}`);
  });
}

//启动ShareWAF
start_sharewaf();

var request = require('request');

//sharewaf地址和端口
var sharewaf_host = "http://127.0.0.1:" + require('./config.js').shield_port + "/";
console.log("sharewaf address:",sharewaf_host);

//10秒检测一次sharewaf服务是否正常
setInterval(function(){
  
  //访问sharewaf
  request.get(sharewaf_host, {timeout: 5000}, function(err) {
    if (err != null){
      if(err.code == 'ETIMEDOUT' || err.code =='ECONNREFUSED' || err.code=='ESOCKETTIMEDOUT'){

        //重启sharewaf
        stop_sharewaf();
        start_sharewaf();
      }else{
        console.log("Error:",err.code);
      }
    }
  }); 
}, 10000);
