﻿var sa_origins_host = "http://127.0.0.1:8080";
var oem_title = "ShareWAF Control Center";