# -*- coding: utf-8 -*-

from clients.mongo_client import get_mongo_client # noqa
