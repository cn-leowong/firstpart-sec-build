# -*- coding: utf-8 -*-

from clients import get_config_redis_client as get_redis_client # noqa