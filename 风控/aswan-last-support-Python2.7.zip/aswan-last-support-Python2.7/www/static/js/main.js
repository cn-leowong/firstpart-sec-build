$(document).ready(function () {
    $('#extra-side-menu').metisMenu();
});
